#!/usr/bin/env python3
"""Recompute a descriptive headroom statistic from the existing eight endpoints.
No training, inference, network, or stochastic significance test is performed.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

TASKS = ('HallusionBench', 'LLaVABench', 'MMBench', 'MMMU_DEV_VAL',
         'MMStar', 'MMVet', 'MathVista_MINI', 'OCRBench')
ACTIONS = ('replay', 'fresh_selected', 'fresh_law', 'source_only_fresh')
STATES = ('init', 'used')
SOURCE = ('https://github.com/Nhckdvrl/ssn-group-papaer/blob/'
          'b427e4d749966513f841e59b77656f51df0cad50/'
          'workbench/data-centric-rsi/results/E13_E14_seed29_terminal_scores.csv')

def calculate(path: Path) -> dict:
    data = path.read_bytes()
    with path.open(newline='', encoding='utf-8') as stream:
        rows = list(csv.DictReader(stream))
    expected = {f'{s}_{a}_s29' for s in STATES for a in ACTIONS}
    if len(rows) != 8 or {r['name'] for r in rows} != expected:
        raise ValueError('Expected exactly the eight original seed29 endpoints.')
    table = {s: {} for s in STATES}
    errors = []
    for row in rows:
        state = next(s for s in STATES if row['name'].startswith(s + '_'))
        action = row['name'][len(state) + 1:-4]
        scores = [float(row[t]) for t in TASKS]
        if not all(math.isfinite(v) for v in scores):
            raise ValueError(f'Non-finite score in {row["name"]}')
        recomputed = math.fsum(scores) / len(TASKS)
        error = abs(recomputed - float(row['mean_percent']))
        if error > 1e-10:
            raise ValueError(f'Mean mismatch in {row["name"]}: {error}')
        errors.append(error)
        table[state][action] = float(row['mean_percent'])
    fixed = {a: math.fsum(table[s][a] for s in STATES) / 2 for a in ACTIONS}
    best_fixed = max(fixed, key=fixed.get)
    oracle_actions = {s: max(table[s], key=table[s].get) for s in STATES}
    oracle = math.fsum(table[s][oracle_actions[s]] for s in STATES) / 2
    contrasts = {}
    for a, b in [('fresh_selected', 'fresh_law'), ('fresh_selected', 'replay'),
                 ('fresh_law', 'replay'), ('source_only_fresh', 'fresh_law')]:
        d = {s: table[s][a] - table[s][b] for s in STATES}
        contrasts[f'{a}_minus_{b}'] = dict(d, used_minus_init=d['used'] - d['init'])
    return {
        'source_url': SOURCE,
        'local_csv_sha256': hashlib.sha256(data).hexdigest(),
        'scope': 'POST-HOC descriptive analysis; one seed; two equally weighted related states',
        'not_established': ['population upper bound', 'equivalence', 'confidence interval',
                            'general data-selection limit', 'new method benefit'],
        'max_recomputed_mean_error': max(errors),
        'state_action_mean_percent': table,
        'contrasts_pp': contrasts,
        'fixed_action_equal_state_mean_percent': fixed,
        'best_fixed_action': best_fixed,
        'hindsight_state_conditioned_actions': oracle_actions,
        'hindsight_state_conditioned_mean_percent': oracle,
        'observed_oracle_minus_best_fixed_pp': oracle - fixed[best_fixed],
        'new_gpu_runs': 0,
    }

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=Path(__file__).with_name('terminal_scores.csv'))
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('headroom_analysis.json'))
    args = parser.parse_args()
    result = calculate(args.input)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
